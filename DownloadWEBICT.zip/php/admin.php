<?php
require_once( dirname(__FILE__).'/form.lib.php' );

define( 'PHPFMG_USER', "Dotace@jvkops.cz" ); // must be a email address. for sending password to you.
define( 'PHPFMG_PW', "4b001c" );

?>
<?php
/**
 * GNU Library or Lesser General Public License version 2.0 (LGPLv2)
*/

# main
# ------------------------------------------------------
error_reporting( E_ERROR ) ;
phpfmg_admin_main();
# ------------------------------------------------------




function phpfmg_admin_main(){
    $mod  = isset($_REQUEST['mod'])  ? $_REQUEST['mod']  : '';
    $func = isset($_REQUEST['func']) ? $_REQUEST['func'] : '';
    $function = "phpfmg_{$mod}_{$func}";
    if( !function_exists($function) ){
        phpfmg_admin_default();
        exit;
    };

    // no login required modules
    $public_modules   = false !== strpos('|captcha|', "|{$mod}|", "|ajax|");
    $public_functions = false !== strpos('|phpfmg_ajax_submit||phpfmg_mail_request_password||phpfmg_filman_download||phpfmg_image_processing||phpfmg_dd_lookup|', "|{$function}|") ;   
    if( $public_modules || $public_functions ) { 
        $function();
        exit;
    };
    
    return phpfmg_user_isLogin() ? $function() : phpfmg_admin_default();
}

function phpfmg_ajax_submit(){
    $phpfmg_send = phpfmg_sendmail( $GLOBALS['form_mail'] );
    $isHideForm  = isset($phpfmg_send['isHideForm']) ? $phpfmg_send['isHideForm'] : false;

    $response = array(
        'ok' => $isHideForm,
        'error_fields' => isset($phpfmg_send['error']) ? $phpfmg_send['error']['fields'] : '',
        'OneEntry' => isset($GLOBALS['OneEntry']) ? $GLOBALS['OneEntry'] : '',
    );
    
    @header("Content-Type:text/html; charset=$charset");
    echo "<html><body><script>
    var response = " . json_encode( $response ) . ";
    try{
        parent.fmgHandler.onResponse( response );
    }catch(E){};
    \n\n";
    echo "\n\n</script></body></html>";

}


function phpfmg_admin_default(){
    if( phpfmg_user_login() ){
        phpfmg_admin_panel();
    };
}



function phpfmg_admin_panel()
{    
    phpfmg_admin_header();
    phpfmg_writable_check();
?>    
<table cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td valign=top style="padding-left:280px;">

<style type="text/css">
    .fmg_title{
        font-size: 16px;
        font-weight: bold;
        padding: 10px;
    }
    
    .fmg_sep{
        width:32px;
    }
    
    .fmg_text{
        line-height: 150%;
        vertical-align: top;
        padding-left:28px;
    }

</style>

<script type="text/javascript">
    function deleteAll(n){
        if( confirm("Are you sure you want to delete?" ) ){
            location.href = "admin.php?mod=log&func=delete&file=" + n ;
        };
        return false ;
    }
</script>


<div class="fmg_title">
    1. Email Traffics
</div>
<div class="fmg_text">
    <a href="admin.php?mod=log&func=view&file=1">view</a> &nbsp;&nbsp;
    <a href="admin.php?mod=log&func=download&file=1">download</a> &nbsp;&nbsp;
    <?php 
        if( file_exists(PHPFMG_EMAILS_LOGFILE) ){
            echo '<a href="#" onclick="return deleteAll(1);">delete all</a>';
        };
    ?>
</div>


<div class="fmg_title">
    2. Form Data
</div>
<div class="fmg_text">
    <a href="admin.php?mod=log&func=view&file=2">view</a> &nbsp;&nbsp;
    <a href="admin.php?mod=log&func=download&file=2">download</a> &nbsp;&nbsp;
    <?php 
        if( file_exists(PHPFMG_SAVE_FILE) ){
            echo '<a href="#" onclick="return deleteAll(2);">delete all</a>';
        };
    ?>
</div>

<div class="fmg_title">
    3. Form Generator
</div>
<div class="fmg_text">
    <a href="http://www.formmail-maker.com/generator.php" onclick="document.frmFormMail.submit(); return false;" title="<?php echo htmlspecialchars(PHPFMG_SUBJECT);?>">Edit Form</a> &nbsp;&nbsp;
    <a href="http://www.formmail-maker.com/generator.php" >New Form</a>
</div>
    <form name="frmFormMail" action='http://www.formmail-maker.com/generator.php' method='post' enctype='multipart/form-data'>
    <input type="hidden" name="uuid" value="<?php echo PHPFMG_ID; ?>">
    <input type="hidden" name="external_ini" value="<?php echo function_exists('phpfmg_formini') ?  phpfmg_formini() : ""; ?>">
    </form>

		</td>
	</tr>
</table>

<?php
    phpfmg_admin_footer();
}



function phpfmg_admin_header( $title = '' ){
    header( "Content-Type: text/html; charset=" . PHPFMG_CHARSET );
?>
<html>
<head>
    <title><?php echo '' == $title ? '' : $title . ' | ' ; ?>PHP FormMail Admin Panel </title>
    <meta name="keywords" content="PHP FormMail Generator, PHP HTML form, send html email with attachment, PHP web form,  Free Form, Form Builder, Form Creator, phpFormMailGen, Customized Web Forms, phpFormMailGenerator,formmail.php, formmail.pl, formMail Generator, ASP Formmail, ASP form, PHP Form, Generator, phpFormGen, phpFormGenerator, anti-spam, web hosting">
    <meta name="description" content="PHP formMail Generator - A tool to ceate ready-to-use web forms in a flash. Validating form with CAPTCHA security image, send html email with attachments, send auto response email copy, log email traffics, save and download form data in Excel. ">
    <meta name="generator" content="PHP Mail Form Generator, phpfmg.sourceforge.net">

    <style type='text/css'>
    body, td, label, div, span{
        font-family : Verdana, Arial, Helvetica, sans-serif;
        font-size : 12px;
    }
    </style>
</head>
<body  marginheight="0" marginwidth="0" leftmargin="0" topmargin="0">

<table cellspacing=0 cellpadding=0 border=0 width="100%">
    <td nowrap align=center style="background-color:#024e7b;padding:10px;font-size:18px;color:#ffffff;font-weight:bold;width:250px;" >
        Form Admin Panel
    </td>
    <td style="padding-left:30px;background-color:#86BC1B;width:100%;font-weight:bold;" >
        &nbsp;
<?php
    if( phpfmg_user_isLogin() ){
        echo '<a href="admin.php" style="color:#ffffff;">Main Menu</a> &nbsp;&nbsp;' ;
        echo '<a href="admin.php?mod=user&func=logout" style="color:#ffffff;">Logout</a>' ;
    }; 
?>
    </td>
</table>

<div style="padding-top:28px;">

<?php
    
}


function phpfmg_admin_footer(){
?>

</div>

<div style="color:#cccccc;text-decoration:none;padding:18px;font-weight:bold;">
	:: <a href="http://phpfmg.sourceforge.net" target="_blank" title="Free Mailform Maker: Create read-to-use Web Forms in a flash. Including validating form with CAPTCHA security image, send html email with attachments, send auto response email copy, log email traffics, save and download form data in Excel. " style="color:#cccccc;font-weight:bold;text-decoration:none;">PHP FormMail Generator</a> ::
</div>

</body>
</html>
<?php
}


function phpfmg_image_processing(){
    $img = new phpfmgImage();
    $img->out_processing_gif();
}


# phpfmg module : captcha
# ------------------------------------------------------
function phpfmg_captcha_get(){
    $img = new phpfmgImage();
    $img->out();
    //$_SESSION[PHPFMG_ID.'fmgCaptchCode'] = $img->text ;
    $_SESSION[ phpfmg_captcha_name() ] = $img->text ;
}



function phpfmg_captcha_generate_images(){
    for( $i = 0; $i < 50; $i ++ ){
        $file = "$i.png";
        $img = new phpfmgImage();
        $img->out($file);
        $data = base64_encode( file_get_contents($file) );
        echo "'{$img->text}' => '{$data}',\n" ;
        unlink( $file );
    };
}


function phpfmg_dd_lookup(){
    $paraOk = ( isset($_REQUEST['n']) && isset($_REQUEST['lookup']) && isset($_REQUEST['field_name']) );
    if( !$paraOk )
        return;
        
    $base64 = phpfmg_dependent_dropdown_data();
    $data = @unserialize( base64_decode($base64) );
    if( !is_array($data) ){
        return ;
    };
    
    
    foreach( $data as $field ){
        if( $field['name'] == $_REQUEST['field_name'] ){
            $nColumn = intval($_REQUEST['n']);
            $lookup  = $_REQUEST['lookup']; // $lookup is an array
            $dd      = new DependantDropdown(); 
            echo $dd->lookupFieldColumn( $field, $nColumn, $lookup );
            return;
        };
    };
    
    return;
}


function phpfmg_filman_download(){
    if( !isset($_REQUEST['filelink']) )
        return ;
        
    $info =  @unserialize(base64_decode($_REQUEST['filelink']));
    if( !isset($info['recordID']) ){
        return ;
    };
    
    $file = PHPFMG_SAVE_ATTACHMENTS_DIR . $info['recordID'] . '-' . $info['filename'];
    phpfmg_util_download( $file, $info['filename'] );
}


class phpfmgDataManager
{
    var $dataFile = '';
    var $columns = '';
    var $records = '';
    
    function phpfmgDataManager(){
        $this->dataFile = PHPFMG_SAVE_FILE; 
    }
    
    function parseFile(){
        $fp = @fopen($this->dataFile, 'rb');
        if( !$fp ) return false;
        
        $i = 0 ;
        $phpExitLine = 1; // first line is php code
        $colsLine = 2 ; // second line is column headers
        $this->columns = array();
        $this->records = array();
        $sep = chr(0x09);
        while( !feof($fp) ) { 
            $line = fgets($fp);
            $line = trim($line);
            if( empty($line) ) continue;
            $line = $this->line2display($line);
            $i ++ ;
            switch( $i ){
                case $phpExitLine:
                    continue;
                    break;
                case $colsLine :
                    $this->columns = explode($sep,$line);
                    break;
                default:
                    $this->records[] = explode( $sep, phpfmg_data2record( $line, false ) );
            };
        }; 
        fclose ($fp);
    }
    
    function displayRecords(){
        $this->parseFile();
        echo "<table border=1 style='width=95%;border-collapse: collapse;border-color:#cccccc;' >";
        echo "<tr><td>&nbsp;</td><td><b>" . join( "</b></td><td>&nbsp;<b>", $this->columns ) . "</b></td></tr>\n";
        $i = 1;
        foreach( $this->records as $r ){
            echo "<tr><td align=right>{$i}&nbsp;</td><td>" . join( "</td><td>&nbsp;", $r ) . "</td></tr>\n";
            $i++;
        };
        echo "</table>\n";
    }
    
    function line2display( $line ){
        $line = str_replace( array('"' . chr(0x09) . '"', '""'),  array(chr(0x09),'"'),  $line );
        $line = substr( $line, 1, -1 ); // chop first " and last "
        return $line;
    }
    
}
# end of class



# ------------------------------------------------------
class phpfmgImage
{
    var $im = null;
    var $width = 73 ;
    var $height = 33 ;
    var $text = '' ; 
    var $line_distance = 8;
    var $text_len = 4 ;

    function phpfmgImage( $text = '', $len = 4 ){
        $this->text_len = $len ;
        $this->text = '' == $text ? $this->uniqid( $this->text_len ) : $text ;
        $this->text = strtoupper( substr( $this->text, 0, $this->text_len ) );
    }
    
    function create(){
        $this->im = imagecreate( $this->width, $this->height );
        $bgcolor   = imagecolorallocate($this->im, 255, 255, 255);
        $textcolor = imagecolorallocate($this->im, 0, 0, 0);
        $this->drawLines();
        imagestring($this->im, 5, 20, 9, $this->text, $textcolor);
    }
    
    function drawLines(){
        $linecolor = imagecolorallocate($this->im, 210, 210, 210);
    
        //vertical lines
        for($x = 0; $x < $this->width; $x += $this->line_distance) {
          imageline($this->im, $x, 0, $x, $this->height, $linecolor);
        };
    
        //horizontal lines
        for($y = 0; $y < $this->height; $y += $this->line_distance) {
          imageline($this->im, 0, $y, $this->width, $y, $linecolor);
        };
    }
    
    function out( $filename = '' ){
        if( function_exists('imageline') ){
            $this->create();
            if( '' == $filename ) header("Content-type: image/png");
            ( '' == $filename ) ? imagepng( $this->im ) : imagepng( $this->im, $filename );
            imagedestroy( $this->im ); 
        }else{
            $this->out_predefined_image(); 
        };
    }

    function uniqid( $len = 0 ){
        $md5 = md5( uniqid(rand()) );
        return $len > 0 ? substr($md5,0,$len) : $md5 ;
    }
    
    function out_predefined_image(){
        header("Content-type: image/png");
        $data = $this->getImage(); 
        echo base64_decode($data);
    }
    
    // Use predefined captcha random images if web server doens't have GD graphics library installed  
    function getImage(){
        $images = array(
			'197A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcklEQVR4nGNYhQEaGAYTpIn7GB0YQ1hDA1qRxVgdWIH8gKkOSGKiDiKNDg0BAQEoeoFijY4OIkjuW5m1dGnW0pVZ05DcB7Qj0GEKI0wdVIyh0SGAMTQERYwFaBq6OtZW1gZUMdEQoJvRxAYq/KgIsbgPAJvzyPC8CtiFAAAAAElFTkSuQmCC',
			'732A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAc0lEQVR4nGNYhQEaGAYTpIn7QkNZQxhCGVpRRFtFWhkdHaY6oIgxNLo2BAQEIItNAekLdBBBdl/UqrBVKzOzpiG5j9EBqK6VEaYODFkbGBodpjCGhiCJiYDEAlDVBTQA3eKALsYawhoaiCI2UOFHRYjFfQBc88qbGhSSiwAAAABJRU5ErkJggg==',
			'15E5' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaklEQVR4nGNYhQEaGAYTpIn7GB1EQ1lDHUMDkMRYHUQaWIEyyOpEsYgxOoiEAMVcHZDctzJr6tKloSujopDcB9TV6AqkRVD0YhMTAYoBSRQx1lbWBoYAZPeJhjCGsIY6THUYBOFHRYjFfQDKg8gfVLUv5QAAAABJRU5ErkJggg==',
			'ADC9' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZklEQVR4nGNYhQEaGAYTpIn7GB1EQxhCHaY6IImxBoi0MjoEBAQgiYlMEWl0bRB0EEESC2gFiTHCxMBOilo6bWUqkApDch9EHcNUZL2hoWCxBkzzBNDtwHBLQCummwcq/KgIsbgPADsyzVps5NUXAAAAAElFTkSuQmCC',
			'2DBB' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYklEQVR4nGNYhQEaGAYTpIn7WANEQ1hDGUMdkMREpoi0sjY6OgQgiQW0ijS6NgQ6iCDrBokh1EHcNG3aytTQlaFZyO4LQFEHhowOmOaxNmCKiTRguiU0FNPNAxV+VIRY3AcAjYjMfhj1eckAAAAASUVORK5CYII=',
			'E961' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYElEQVR4nGNYhQEaGAYTpIn7QkMYQxhCGVqRxQIaWFsZHR2mooqJNLo2OIRiisH1gp0UGrV0aerUVUuR3RfQwBjo6uiAZgcDUG8AmhgLFjGwW1DEoG4ODRgE4UdFiMV9AM9mzY6mg5msAAAAAElFTkSuQmCC',
			'BC8B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWklEQVR4nGNYhQEaGAYTpIn7QgMYQxlCGUMdkMQCprA2Ojo6OgQgi7WKNLg2BDqIoKgTaWBEqAM7KTRqGpBYGZqF5D40dXDzWNHNw2oHpluwuXmgwo+KEIv7AHMdzTYszk9OAAAAAElFTkSuQmCC',
			'5381' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7QkNYQxhCGVqRxQIaRFoZHR2moooxNLo2BIQiiwUGMIDUwfSCnRQ2bVXYqtBVS1Hc14qiDiYGMg/VXixiIlNEMPSyBoDdHBowCMKPihCL+wACyMwEtt8cKQAAAABJRU5ErkJggg==',
			'662D' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7WAMYQxhCGUMdkMREprC2Mjo6OgQgiQW0iDSyNgQ6iCCLNYB4cDGwkyKjpoWtWpmZNQ3JfSFTRFsZWhlR9baKNDpMwSIWgCoGdosDI4pbQG5mDQ1EcfNAhR8VIRb3AQBp3MrIE8N7wQAAAABJRU5ErkJggg==',
			'A516' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdUlEQVR4nGNYhQEaGAYTpIn7GB1EQxmmMEx1QBJjDRBpYAhhCAhAEhOZItLAGMLoIIAkFtAqEsIwhdEB2X1RS6cuXTVtZWoWkvsCWhkaHaYwopgXGgoWcxBBNQ+LGGsr0H0oegNagS4JdUBx80CFHxUhFvcBAGFLy/uONHZlAAAAAElFTkSuQmCC',
			'F685' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7QkMZQxhCGUMDkMQCGlhbGR0dHRhQxEQaWRsC0cUagOpcHZDcFxo1LWxV6MqoKCT3BTSIAs1zAKpGNc8VbAK6WKCDCIZbHAJQ3QdyM8NUh0EQflSEWNwHABNazGgFCOteAAAAAElFTkSuQmCC',
			'FA66' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaElEQVR4nGNYhQEaGAYTpIn7QkMZAhhCGaY6IIkFNDCGMDo6BASgiLG2sjY4OgigiIk0ujYwOiC7LzRq2srUqStTs5DcB1bn6Ihmnmioa0OggwiGeZhijhhuEWl0QHPzQIUfFSEW9wEArCjNxmb4eKsAAAAASUVORK5CYII=',
			'82F4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nM2QMQ7AIAhFceAG9j4u7gyyeBocvIFXcPGU1Q1sxzYtfyB5+SEvwLiMwJ/yih+SS8gkpJhvWFGgaEbVlyhQbQ8Wa6T8eh6988hZ+c1eQ3HB3gOajJNhLuDa1kV2hnRw3NhX/3swN34nt83NWlDjjCsAAAAASUVORK5CYII=',
			'3788' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7RANEQx1CGaY6IIkFTGFodHR0CAhAVtnK0OjaEOgggiw2haGVEaEO7KSVUaumrQpdNTUL2X1TGAIYMcxjdGBFN6+VtQFdLGCKSAO6XtEAoAo0Nw9U+FERYnEfANOTy8jBUOnhAAAAAElFTkSuQmCC',
			'B297' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAc0lEQVR4nGNYhQEaGAYTpIn7QgMYQxhCGUNDkMQCprC2Mjo6NIggi7WKNLo2BKCKTWEAiwUguS80atXSlZlRK7OQ3AdUN4UhJKCVAcU8hgCwDIoYowNjQ0AAA6pbGhgdHR1Q3Swa6hDKiCI2UOFHRYjFfQCqBs0UdmNdJQAAAABJRU5ErkJggg==',
			'538D' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7QkNYQxhCGUMdkMQCGkRaGR0dHQJQxBgaXRsCHUSQxAIDGMDqRJDcFzZtVdiq0JVZ05Dd14qiDiaGYV4AFjGRKZhuYQ3AdPNAhR8VIRb3AQDMJMr+4Xm/CQAAAABJRU5ErkJggg==',
			'681E' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYklEQVR4nGNYhQEaGAYTpIn7WAMYQximMIYGIImJTGFtZQhhdEBWF9Ai0uiILtYAVDcFLgZ2UmTUyrBV01aGZiG5L2QKijqI3laRRgcixESw6AW5mTHUEcXNAxV+VIRY3AcAOX/J8ImpCwwAAAAASUVORK5CYII=',
			'1A9F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7GB0YAhhCGUNDkMRYHRhDGB0dHZDViTqwtrI2BDqg6hVpdEWIgZ20MmvayszMyNAsJPeB1DmEoOsVDXXAYp4jNjF0t4QAzQtlRBEbqPCjIsTiPgDnA8dh9HIMowAAAABJRU5ErkJggg==',
			'D233' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7QgMYQxhDGUIdkMQCprC2sjY6OgQgi7WKNDo0BDSIoIgxNDqARRHui1q6aumqqauWZiG5D6huCgNCHUwsgAHDPEYHDLEprA3obgkNEA11RHPzQIUfFSEW9wEAQ3jPZ4cNmCcAAAAASUVORK5CYII=',
			'E416' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7QkMYWhmmMEx1QBILaGCYyhDCEBCAKhbKGMLoIIAixujKMIXRAdl9oVFLl66atjI1C8l9AQ0iQDsY0cwTDXUA6hVBtQOkDosYqltAbmYMdUBx80CFHxUhFvcBAMQOzAOqUpYmAAAAAElFTkSuQmCC',
			'3C4A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaElEQVR4nGNYhQEaGAYTpIn7RAMYQxkaHVqRxQKmsAJFHKY6IKtsFWkAigQEIItNEWlgCHR0EEFy38qoaatWZmZmTUN2H1AdayNcHdw81tDA0BB0O9DUgd2CJgZxM5p5AxR+VIRY3AcAPB7M2ifgAn0AAAAASUVORK5CYII=',
			'87DB' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7WANEQ11DGUMdkMREpjA0ujY6OgQgiQW0AsUaAh1EUNW1sgLFApDctzRq1bSlqyJDs5DcB1QXgKQOah6jAyuaeQFA09DFRKaINLCiuYU1ACiG5uaBCj8qQizuAwC5o8yB/Mf7ewAAAABJRU5ErkJggg==',
			'6D34' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpIn7WANEQxhDGRoCkMREpoi0sjY6NCKLBbSINDo0BLSiiDUAxRodpgQguS8yatrKrKmroqKQ3BcyBaTO0QFFbyvIvMDQEAyxAGxuQRHD5uaBCj8qQizuAwASwtAmKaubVAAAAABJRU5ErkJggg==',
			'81A0' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpIn7WAMYAhimMLQii4lMYQxgCGWY6oAkFtDKGsDo6BAQgKKOIYC1IdBBBMl9S6NWRS1dFZk1Dcl9aOqg5gHFQrGINQRgsSMAxS2sQJ2sINWDIPyoCLG4DwAlLMrQ+ekvnwAAAABJRU5ErkJggg==',
			'6EA1' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7WANEQxmmMLQii4lMEWlgCGWYiiwW0CLSwOjoEIoi1iDSwNoQANMLdlJk1NSwpauiliK7L2QKijqI3lagWCgWMTR1Ilj0gtwMFAsNGAThR0WIxX0ApsjM3P12UAYAAAAASUVORK5CYII=',
			'8515' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcUlEQVR4nGNYhQEaGAYTpIn7WANEQxmmMIYGIImJTBFpYAhhdEBWF9Aq0sCIJgZUFwLU6+qA5L6lUVOXrpq2MioKyX0iUxgaHaYAaRTzsImJAMUYHURQ7GBtZZjCEIDsPtYAoEtCHaY6DILwoyLE4j4A3mjLcaZlTjUAAAAASUVORK5CYII=',
			'092F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7GB0YQxhCGUNDkMRYA1hbGR0dHZDViUwRaXRtCEQRC2gVaXRAiIGdFLV06dKslZmhWUjuC2hlDHRoZUTTy9DoMIURzQ6WRocAVDGwWxxQxUBuZg1FdctAhR8VIRb3AQAz0sjM2Ve4DQAAAABJRU5ErkJggg==',
			'D4C4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaklEQVR4nGNYhQEaGAYTpIn7QgMYWhlCHRoCkMQCpjBMZXQIaEQRA6pibRBoRRVjdGVtYJgSgOS+qKVAAKSikNwX0CrSytoANBFFr2ioawNjaAiqHUB1AuhuaQXpRBbD5uaBCj8qQizuAwC2+88N8vULFwAAAABJRU5ErkJggg==',
			'D8CB' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXklEQVR4nGNYhQEaGAYTpIn7QgMYQxhCHUMdkMQCprC2MjoEOgQgi7WKNLo2CDqIoIixtrI2MMLUgZ0UtXRl2NJVK0OzkNyHpg7JPEY087DYgcUt2Nw8UOFHRYjFfQA0MM0AtmxmHwAAAABJRU5ErkJggg==',
			'A9C0' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7GB0YQxhCHVqRxVgDWFsZHQKmOiCJiUwRaXRtEAgIQBILaAWJMTqIILkvaunSpamrVmZNQ3JfQCtjIJI6MAwNZWhEFwtoZcFiB6ZbgOZhuHmgwo+KEIv7AKl2zNXcKaVTAAAAAElFTkSuQmCC',
			'7628' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdElEQVR4nGNYhQEaGAYTpIn7QkMZQxhCGaY6IIu2srYyOjoEBKCIiTSyNgQ6iCCLTQHxAmDqIG6Kmha2amXW1Cwk9zE6iLYytDKgmMfaINLoMIURxTwRkFgAqlhAA9AtDqh6AxoYQ1hDA1DdPEDhR0WIxX0AC1HLXYcG66IAAAAASUVORK5CYII=',
			'DB7F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYklEQVR4nGNYhQEaGAYTpIn7QgNEQ1hDA0NDkMQCpoi0MjQEOiCrC2gVaXTAFGtlaHSEiYGdFLV0atiqpStDs5DcB1Y3hRHTvABMMUcHNDGgW1gbUMXAbkYTG6jwoyLE4j4AIPXLyK09KUEAAAAASUVORK5CYII=',
			'4AD8' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpI37pjAEsIYyTHVAFgthDGFtdAgIQBIDirSyNgQ6iCCJsU4RaXRtCICpAztp2rRpK1NXRU3NQnJfAKo6MAwNFQ11RTOPAawOixiaW8Bi6G4eqPCjHsTiPgC4Gs3SCSA6jAAAAABJRU5ErkJggg==',
			'DF1F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWElEQVR4nGNYhQEaGAYTpIn7QgNEQx2mMIaGIIkFTBFpYAhhdEBWF9Aq0sCIRYxhClwM7KSopVPDVk1bGZqF5D40daSJTcEUCw0AuiXUEUVsoMKPihCL+wCLTcrLvBK6UAAAAABJRU5ErkJggg==',
			'88BF' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAUklEQVR4nGNYhQEaGAYTpIn7WAMYQ1hDGUNDkMREprC2sjY6OiCrC2gVaXRtCEQRQ1MHdtLSqJVhS0NXhmYhuY9Y84iwA9nNKGIDFX5UhFjcBwB8GMrCn/qjMgAAAABJRU5ErkJggg==',
			'2182' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcUlEQVR4nM2QzQ2AMAhG6YENOhBu8JnIxWnw0A2qQzCltSeMHjUpJBxe+HmB/BFGI+UvfgwCKe0SWK4JaRIgMBQG2yw5The6+ixHv8NXV28l+KH3bfFGEmr7UG4u1lmNrO3uLpGpspImXQb434f54ncCclTJKkZ9xYMAAAAASUVORK5CYII=',
			'F6CA' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7QkMZQxhCHVqRxQIaWFsZHQKmOqCIiTSyNggEBKCKNbA2MDqIILkvNGpa2NJVK7OmIbkvoEG0FUkd3DzXBsbQEAwxQTR1ILcEoomB3OyIIjZQ4UdFiMV9ALLdzIUpN9sGAAAAAElFTkSuQmCC',
			'291C' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcUlEQVR4nGNYhQEaGAYTpIn7WAMYQximMEwNQBITmcLayhDCECCCJBbQKtLoGMLowIKsGyjmMIXRAcV905YuzZq2MgvFfQGMgUjqwBDIa0QXY21gAYsh2yHSAHTLFFS3hIYyhjCGOqC4eaDCj4oQi/sAytrKU1ALeEAAAAAASUVORK5CYII=',
			'6F5B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7WANEQ11DHUMdkMREpog0sDYwOgQgiQW0QMREkMUagGJT4erAToqMmhq2NDMzNAvJfSFTQLoCUc1rhYiJoImxoomB3MLo6IiilzUAqCKUEcXNAxV+VIRY3AcAbDvLkoblY1UAAAAASUVORK5CYII=',
			'77A6' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7QkNFQx2mMEx1QBZtZWh0CGUICEATc3R0dBBAFpvC0MraEOiA4r6oVdOWropMzUJyH6MDQwBQHYp5rEBR1tBABxEkMRGgKMg8ZLEAsGgAil6oGKqbByj8qAixuA8A+APMPE0r/MQAAAAASUVORK5CYII=',
			'FDC0' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAVElEQVR4nGNYhQEaGAYTpIn7QkNFQxhCHVqRxQIaRFoZHQKmOqCKNbo2CAQEYIgxOogguS80atrK1FUrs6YhuQ9NHQExDDuwuAXTzQMVflSEWNwHALWKzkC/npolAAAAAElFTkSuQmCC',
			'49A2' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAd0lEQVR4nM2Quw2AMAwFHQlvkIFIQW+kuKFnD6fIBiYbpGFKoMJ8SpDi152e7JNhfYxAS/nHT10EhaW3LGIGBiLDXPQphNB7w1B9GoTEG79Sap3Xac/pR+rGvZfsDWZIA1O+unTHPr0yzChEd2eUkWML//suL34bLrrNPlQcy08AAAAASUVORK5CYII=',
			'768A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7QkMZQxhCGVpRRFtZWxkdHaY6oIiJNLI2BAQEIItNEWlgdHR0EEF2X9S0sFWhK7OmIbmP0UG0FUkdGLI2iDS6NgSGhiCJiUDEUNQFNLBi6A1oALmZEUVsoMKPihCL+wBtxMrOpHhIJAAAAABJRU5ErkJggg==',
			'453F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpI37poiGMgJhCLJYiEgDa6OjA7I6RqAYQ0MgihjrFJEQBoQ6sJOmTZu6dNXUlaFZSO4LmMLQ6IBmXmgoUAzNPIYpIljEWFvR3cIwhTEE6GZUsYEKP+pBLO4DABANyoRSmGwHAAAAAElFTkSuQmCC',
			'68D8' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7WAMYQ1hDGaY6IImJTGFtZW10CAhAEgtoEWl0bQh0EEEWawCqawiAqQM7KTJqZdjSVVFTs5DcFzIFRR1EbysW87CIYXMLNjcPVPhREWJxHwAJpc24VyOv4wAAAABJRU5ErkJggg==',
			'D5C6' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7QgNEQxlCHaY6IIkFTBFpYHQICAhAFmsVaWBtEHQQQBULYQWqRHZf1NKpS5euWpmaheS+gFaGRtcGRjTzwGIOIqjmAcUEUcWmsLaiuyU0gDEE3c0DFX5UhFjcBwDHr82CXSVk+QAAAABJRU5ErkJggg==',
			'D5B8' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7QgNEQ1lDGaY6IIkFTBFpYG10CAhAFmsFijUEOoigioUgqQM7KWrp1KVLQ1dNzUJyX0ArQ6MrhnlAMUzzMMWmsLaiuyU0gDEE3c0DFX5UhFjcBwCvcM8GSfkT7AAAAABJRU5ErkJggg==',
			'28BF' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYElEQVR4nGNYhQEaGAYTpIn7WAMYQ1hDGUNDkMREprC2sjY6OiCrC2gVaXRtCEQRY2hFUQdx07SVYUtDV4ZmIbsvANM8RgdM81gbMMVEGjD1hoaC3YzqlgEKPypCLO4DAG8zyeVUuvomAAAAAElFTkSuQmCC',
			'A28D' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7GB0YQxhCGUMdkMRYA1hbGR0dHQKQxESmiDS6NgQ6iCCJBbQyNDoC1YkguS9q6aqlq0JXZk1Dch9Q3RRGhDowDA1lCGDFMI/RAVOMtQHdLQGtoqEOaG4eqPCjIsTiPgCy9stD3Fp2EQAAAABJRU5ErkJggg==',
			'A38A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7GB1YQxhCGVqRxVgDRFoZHR2mOiCJiUxhaHRtCAgIQBILaGUAqnN0EEFyX9TSVWGrQldmTUNyH5o6MAwNBZkXGBqCah5IDEVdQKsIht6AVpCbGVHEBir8qAixuA8AXnjLsvH+NlEAAAAASUVORK5CYII=',
			'8592' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAd0lEQVR4nGNYhQEaGAYTpIn7WANEQxlCGaY6IImJTBFpYHR0CAhAEgtoFWlgbQh0EEFVF8LaENAgguS+pVFTl67MjFoVheQ+kSkMjQ4hAY0OKOYBxUAkqh2Njg0BUxhQ7GBtBbkF1c2MIQyhjKEhgyD8qAixuA8A3gfMvDUaTxEAAAAASUVORK5CYII=',
			'EFFB' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAATUlEQVR4nGNYhQEaGAYTpIn7QkNEQ11DA0MdkMQCGkQaWBsYHQKwiIngVgd2UmjU1LCloStDs5DcR6p5eOyAuhkshuLmgQo/KkIs7gMA08zL1PA+s34AAAAASUVORK5CYII=',
			'86FD' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYElEQVR4nGNYhQEaGAYTpIn7WAMYQ1hDA0MdkMREprC2sjYwOgQgiQW0ijSCxERQ1Ik0IImBnbQ0alrY0tCVWdOQ3CcyRbQVXS/IPFcixLC5BezmBkYUNw9U+FERYnEfACPKypZ4oWeXAAAAAElFTkSuQmCC',
			'5D46' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7QkNEQxgaHaY6IIkFNIi0MrQ6BASgigFVOToIIIkFBgDFAh0dkN0XNm3ayszMzNQsZPe1ijS6NjqimAcWCw10EEG2Ayjm0OiIIiYyBeiWRlS3sAZgunmgwo+KEIv7AF9Fzdn+zw3LAAAAAElFTkSuQmCC',
			'D1A4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXklEQVR4nGNYhQEaGAYTpIn7QgMYAhimMDQEIIkFTGEMYAhlaEQRa2UNYHR0aEUVYwhgBaoOQHJf1FIwiopCch9EXaADht7QwNAQTPPQ3IIpFgrUiS42UOFHRYjFfQAx/M4JdITG7AAAAABJRU5ErkJggg==',
			'3C73' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7RAMYQ1lDA0IdkMQCprA2OjQEOgQgq2wVaXBoCGgQQRabAuQ1gkQR7lsZNW3VqqWrlmYhuw+kbgpDA7p5DAEMqOYBxRwdUMVAbnFtYERxC9jNDQwobh6o8KMixOI+APafzV00PPOiAAAAAElFTkSuQmCC',
			'35F0' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7RANEQ1lDA1qRxQKmiDSwNjBMdUBW2QoWCwhAFpsiEsLawOggguS+lVFTly4NXZk1Ddl9UxgaXRHqoOZhExMBiqHaETCFtRXdLaIBjEB7GVDcPFDhR0WIxX0AN33LaZt8w5YAAAAASUVORK5CYII=',
			'0476' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAeUlEQVR4nM2QIQ7DQAwE1+B4weU/LijfgCPlJX2FC/yD5AkHklcmKrKVwlapl4209shYD2P4p/zETxReGmcNrBAzjGRgdUKDjXoJjC43vK4a/e6997Uvj2fwo1fHJGkffWhK0ZpvuGhmu4sXQ+q+nQ3J+az/fTEf/Da6K8reL8CvjAAAAABJRU5ErkJggg==',
			'9EAF' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAY0lEQVR4nGNYhQEaGAYTpIn7WANEQxmmMIaGIImJTBFpYAhldEBWF9Aq0sDo6IghxtoQCBMDO2na1KlhS1dFhmYhuY/VFUUdBIL0hqKKCbRiqgO5BV0M5GYM8wYo/KgIsbgPAPRuyaBVyYrxAAAAAElFTkSuQmCC',
			'991B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7WAMYQximMIY6IImJTGFtZQhhdAhAEgtoFWl0BIqJoIk5TIGrAztp2tSlS7OmrQzNQnIfqytjIJI6CGxlAOtFNk+glQVDDOwWNL0gNzOGOqK4eaDCj4oQi/sAhJXK1kc0SC4AAAAASUVORK5CYII=',
			'D5CB' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7QgNEQxlCHUMdkMQCpog0MDoEOgQgi7WKNLA2CDqIoIqFsAJVBiC5L2rp1KVLV60MzUJyX0ArQ6MrQh2KGJp5QDE0O6awtqK7JTSAMQTdzQMVflSEWNwHAFC/zRofAyPLAAAAAElFTkSuQmCC',
			'C9BA' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7WEMYQ1hDGVqRxURaWVtZGx2mOiCJBTSKNLo2BAQEIIs1AMUaHR1EkNwXtWrp0tTQlVnTkNwX0MAYiKQOKsYANC8wNATFDhaQGIo6iFtQ9ULczIgiNlDhR0WIxX0Ad97NChMpcjsAAAAASUVORK5CYII=',
			'E5BE' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXUlEQVR4nGNYhQEaGAYTpIn7QkNEQ1lDGUMDkMQCGkQaWBsdHRjQxRoC0cVCkNSBnRQaNXXp0tCVoVlI7gOa3eiKYR5QDNM8LGKsrehuCQ1hDEF380CFHxUhFvcBABN9zCbUQFv9AAAAAElFTkSuQmCC',
			'42F4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nM3QsRHAIAhAUSzYINnHxp5CGqfBwg04N7BxysQOY8rkEuje6d0/oC8j8Kd9p09dRCYhaxELCmRrLm45CBRrqDBMyfTV2lvjnpLpIwVFcd7+ZQY6jePc4nG8nwxltZ3D1b6633N703cA/4DM3kAR3aAAAAAASUVORK5CYII=',
			'B1EB' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWklEQVR4nGNYhQEaGAYTpIn7QgMYAlhDHUMdkMQCpjAGsDYwOgQgi7WygsVEUNQxIKsDOyk0alXU0tCVoVlI7kNTBzWPAdM8bGJY9IYCXYzu5oEKPypCLO4DAE0yyd+WSipBAAAAAElFTkSuQmCC',
			'1238' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaklEQVR4nGNYhQEaGAYTpIn7GB0YQxhDGaY6IImxOrC2sjY6BAQgiYk6iDQ6NAQ6iKDoZWh0QKgDO2ll1qqlq6aumpqF5D6guikMaOYBxQIYMMwDimKIsTZguCVENNQRzc0DFX5UhFjcBwC8z8o6e7NA2QAAAABJRU5ErkJggg==',
			'79A2' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAd0lEQVR4nM2QMQ6AMAhFaSI34EDt0J0mZXH3HnToDeoRXDyldRKjoyblby8/8ALsj1EYKb/4ibgMDVZvacUKAsw3RiWE4MmyRiUqK1m/eduWfe65/Jx3qfeKvYEKJQpX60I6nfuaZaxYUZnvzGXUJHmA/32YF78DKTDNONjyGQEAAAAASUVORK5CYII=',
			'8DE1' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWUlEQVR4nGNYhQEaGAYTpIn7WANEQ1hDHVqRxUSmiLSyNjBMRRYLaBVpdG1gCEVTBxKD6QU7aWnUtJWpoauWIrsPTR2yeQTFoG5BEYO6OTRgEIQfFSEW9wEAwR/MtmJ4wMoAAAAASUVORK5CYII=',
			'3D2F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7RANEQxhCGUNDkMQCpoi0Mjo6OqCobBVpdG0IRBWbItLogBADO2ll1LSVWSszQ7OQ3QdS18qIYZ7DFCxiAahiYLc4oIqB3MwaiuaWAQo/KkIs7gMAYszJwIUCypEAAAAASUVORK5CYII=',
			'8735' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdUlEQVR4nGNYhQEaGAYTpIn7WANEQx1DGUMDkMREpjA0ujY6OiCrC2hlaHRoCEQRA6oDijq6OiC5b2nUqmmrpq6MikJyH1BdAEi3CIp5jECzAtDEWIFkoIMIih0iDayNDgHI7mMNEGlgDGWY6jAIwo+KEIv7ALQ2zKiiYyEQAAAAAElFTkSuQmCC',
			'14BD' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZklEQVR4nGNYhQEaGAYTpIn7GB0YWllDGUMdkMRYHRimsjY6OgQgiYk6MISyNgQ6iKDoZXQFqRNBct/KrKVLl4auzJqG5D5GB5FWJHVQMdFQVwzzgG7BJobulhBMNw9U+FERYnEfAJVDyJ2J1lbqAAAAAElFTkSuQmCC',
			'8029' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcUlEQVR4nGNYhQEaGAYTpIn7WAMYAhhCGaY6IImJTGEMYXR0CAhAEgtoZW1lbQh0EEFRJ9LogBADO2lp1LSVWSuzosKQ3AdW18owVQTFPKDYFKAcmh1A16DZAXSLAwOKW0BuZg0NQHHzQIUfFSEW9wEAF93LUXJygX4AAAAASUVORK5CYII=',
			'1519' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7GB1EQxmmMEx1QBJjdRBpYAhhCAhAEhMFijGGMIJkkPSKhDBMgYuBnbQya+rSVdNWRYUhuY/RgaHRAWgHql6wWAOaeSAxNDtYW4HuQ3VLCNAloQ4obh6o8KMixOI+AKZqyMcI4XfBAAAAAElFTkSuQmCC',
			'2AD0' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7WAMYAlhDGVqRxUSmMIawNjpMdUASC2hlbWVtCAgIQNbdKtLo2hDoIILsvmnTVqauisyahuy+ABR1YMjoIBqKLsbaAFKHaocISAzNLaGhQDE0Nw9U+FERYnEfABs7zTu0a2KxAAAAAElFTkSuQmCC',
			'1443' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7GB0YWhkaHUIdkMRYHRimMrQ6OgQgiYk6MIQyTHVoEEHRy+jKEOjQEIDkvpVZS5euzMxamoXkPkYHkVbWRrg6qJhoqGtoAJp5YLdgEUNzSwimmwcq/KgIsbgPAPy/yorJLNLUAAAAAElFTkSuQmCC',
			'D16F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYElEQVR4nGNYhQEaGAYTpIn7QgMYAhhCGUNDkMQCpjAGMDo6OiCrC2hlDWBtQBdjAIoxwsTATopaCkRTV4ZmIbkPrA7DPJDeQMJiUxgw3BIawBoKdDOK2ECFHxUhFvcBADNGyOVzsC5KAAAAAElFTkSuQmCC',
			'7420' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAc0lEQVR4nGNYhQEaGAYTpIn7QkMZWhlAGFm0lWEqo6PDVAdUsVDWhoCAAGSxKYyuDA2BDiLI7otaunTVysysaUjuY3QQaWVoZYSpA0PWBtFQhymoYiIgWwIYUOwAsoE6GVDcAhJjDQ1AdfMAhR8VIRb3AQByWcrhTscrJwAAAABJRU5ErkJggg==',
			'D448' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7QgMYWhkaHaY6IIkFTGGYytDqEBCALNbKEMow1dFBBEWM0ZUhEK4O7KSopUuXrszMmpqF5L6AVpFW1kZ080RDXUMD0cwDuQXNjilg96HoxebmgQo/KkIs7gMAJznOmcBbePcAAAAASUVORK5CYII=',
			'E0D2' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7QkMYAlhDGaY6IIkFNDCGsDY6BASgiLG2sjYEOoigiIk0uoJIJPeFRk1bmboqCggR7oOqa3TA1NvKgGFHwBQGLG7BdDNjaMggCD8qQizuAwCnX84g/t4NtgAAAABJRU5ErkJggg==',
			'FEC4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWUlEQVR4nGNYhQEaGAYTpIn7QkNFQxlCHRoCkMQCGkQaGB0CGtHFWBsEWjHFGKYEILkvNGpq2NJVq6KikNwHUQc0EUMvY2gIph3Y3IImhunmgQo/KkIs7gMAMq7Opsltt8cAAAAASUVORK5CYII=',
			'D0E3' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWElEQVR4nGNYhQEaGAYTpIn7QgMYAlhDHUIdkMQCpjCGsDYwOgQgi7WytrICaREUMZFGVxCN5L6opdNWpoauWpqF5D40dShiIoTswOIWbG4eqPCjIsTiPgDrjs2TRo06TgAAAABJRU5ErkJggg==',
			'FB65' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7QkNFQxhCGUMDkMQCGkRaGR0dHRhQxRpdGzDEWlkbGF0dkNwXGjU1bOnUlVFRSO4Dq3N0aBDBMC8Ai1iggwiGWxwCUN0HcjPDVIdBEH5UhFjcBwAKTc0jat/oFQAAAABJRU5ErkJggg==',
			'9BDE' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWklEQVR4nGNYhQEaGAYTpIn7WANEQ1hDGUMDkMREpoi0sjY6OiCrC2gVaXRtCEQXa2VFiIGdNG3q1LClqyJDs5Dcx+qKog4CsZgngEUMm1uwuXmgwo+KEIv7AMVHywHDF8UyAAAAAElFTkSuQmCC',
			'1161' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAX0lEQVR4nGNYhQEaGAYTpIn7GB0YAhhCGVqRxVgdGAMYHR2mIouJOrAGsDY4hKLrZW2A6wU7aWXWqqilU1ctRXYfWJ2jQyum3gCixBjR9IqGsIYC3RwaMAjCj4oQi/sAT9nG01CTO8kAAAAASUVORK5CYII=',
			'C87E' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7WEMYQ1hDA0MDkMREWllbGRoCHZDVBTSKNDqgizUA1TU6wsTATopatTJs1dKVoVlI7gOrm8KIphdoXgAjhh2ODqhiILewNqCKgd3cwIji5oEKPypCLO4DAHpGyplZVVc1AAAAAElFTkSuQmCC',
			'1AEF' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXUlEQVR4nGNYhQEaGAYTpIn7GB0YAlhDHUNDkMRYHRhDWEEySGKiDqyt6GKMDiKNrggxsJNWZk1bmRq6MjQLyX1o6qBioqGYYtjUYYqJhgDFQh1RxAYq/KgIsbgPADl1xtO/F8TaAAAAAElFTkSuQmCC',
			'0FE8' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXElEQVR4nGNYhQEaGAYTpIn7GB1EQ11DHaY6IImxBog0sDYwBAQgiYlMAYkxOoggiQW0oqgDOylq6dSwpaGrpmYhuQ9NHZIYqnnY7MDmFpAKVjQ3D1T4URFicR8A3p7LHdcVisUAAAAASUVORK5CYII=',
			'C017' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZklEQVR4nGNYhQEaGAYTpIn7WEMYAhimMIaGIImJtDKGMIQAaSSxgEZWkCiqWINIo8MUEI1wX9SqaSuzpq1amYXkPqi6VgZMvVMY0OwAigQwoLtlCqMDupsZQx1RxAYq/KgIsbgPAF3Ey2K+chgBAAAAAElFTkSuQmCC',
			'DCEA' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYElEQVR4nGNYhQEaGAYTpIn7QgMYQ1lDHVqRxQKmsDa6NjBMdUAWaxVpAIoFBKCJsTYwOogguS9q6bRVS0NXZk1Dch+aOmSx0BAMO9DUgd2CKgZxsyOK2ECFHxUhFvcBAKYMzSi/K4KiAAAAAElFTkSuQmCC',
			'3A6F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7RAMYAhhCGUNDkMQCpjCGMDo6OqCobGVtZW1AE5si0ujawAgTAztpZdS0lalTV4ZmIbsPpA7DPNFQ14ZANDGQeahiAUC9jmh6RQNEGh1CGVH1DlD4URFicR8ATr3KFFZlaugAAAAASUVORK5CYII=',
			'F97D' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7QkMZQ1hDA0MdkMQCGlhbGRoCHQJQxEQaHYBiIuhijY4wMbCTQqOWLs1aujJrGpL7AhoYAx2mMKLpZWh0CEAXYwGahi7G2srawIjmFqCbGxhR3DxQ4UdFiMV9AEZwzNcW8Il+AAAAAElFTkSuQmCC',
			'5F44' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7QkNEQx0aHRoCkMQCGkQaGFodGjHEpjq0IosFBgDFAh2mBCC5L2za1LCVmVlRUcjuaxVpYG10dEDWCxYLDQwNQbYDKMaA5haRKZhirAGYYgMVflSEWNwHAOQXzwZVd6dpAAAAAElFTkSuQmCC',
			'9D04' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpIn7WANEQximMDQEIImJTBFpZQhlaEQWC2gVaXR0dGhFF3NtCJgSgOS+aVOnrUxdFRUVheQ+VleQukAHZL0MYL2BoSFIYgIQO7C5BUUMm5sHKvyoCLG4DwD7hs5hBLe/KAAAAABJRU5ErkJggg==',
			'2B10' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7WANEQximMLQii4lMEWllCGGY6oAkFtAq0ugYwhAQgKy7FahuCqODCLL7pk0NWzVtZdY0ZPcFoKgDQyCv0QFNjLUBJIZqh0gDSC+qW0JDRUMYQx1Q3DxQ4UdFiMV9ABQ1y2mle0EqAAAAAElFTkSuQmCC',
			'ACB5' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcUlEQVR4nGNYhQEaGAYTpIn7GB0YQ1lDGUMDkMRYA1gbXRsdHZDViUwRaXBtCEQRC2gVaWBtdHR1QHJf1NJpq5aGroyKQnIfRJ1DgwiS3tBQoFhDAIoYSB3IDlQxkFscAgJQxEBuZpjqMAjCj4oQi/sANwPNeZJC0gMAAAAASUVORK5CYII=',
			'E1BE' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAV0lEQVR4nGNYhQEaGAYTpIn7QkMYAlhDGUMDkMQCGhgDWBsdHRhQxFgDWBsC0cQYkNWBnRQatSpqaejK0Cwk96GpQ4hhMw+/HVA3s4aiu3mgwo+KEIv7APa8yaD08FTHAAAAAElFTkSuQmCC',
			'20B9' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcUlEQVR4nGNYhQEaGAYTpIn7WAMYAlhDGaY6IImJTGEMYW10CAhAEgtoZW1lbQh0EEHW3SrS6NroCBODuGnatJWpoauiwpDdFwBS5zAVWS+jA1CsIaABWYy1AWRHAIodIg2YbgkNxXTzQIUfFSEW9wEAqRXL1jUlIgcAAAAASUVORK5CYII=',
			'D62C' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7QgMYQxhCGaYGIIkFTGFtZXR0CBBBFmsVaWRtCHRgQRUDkoEOyO6LWjotbNXKzCxk9wW0irYytDI6MKCZ5zAFi1gAI6odILc4MKC4BeRm1tAAFDcPVPhREWJxHwAdiswbnPA3HwAAAABJRU5ErkJggg==',
			'1ABA' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7GB0YAlhDGVqRxVgdGENYGx2mOiCJiTqwtrI2BAQEoOgVaXRtdHQQQXLfyqxpK1NDgSSS+9DUQcVEQ10bAkND0M1rCERTh6lXNAQoFsqIIjZQ4UdFiMV9AGUyyiNYvitqAAAAAElFTkSuQmCC',
			'E4AC' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaElEQVR4nGNYhQEaGAYTpIn7QkMYWhmmMEwNQBIDsqcyhDIEiKCKhTI6OjqwoIgxurI2BDoguy80aunSpasis5DdF9Ag0oqkDiomGuoaii7GAFbHgiEWgOIWkJuBYihuHqjwoyLE4j4AbZrMppeT1AkAAAAASUVORK5CYII='        
        );
        $this->text = array_rand( $images );
        return $images[ $this->text ] ;    
    }
    
    function out_processing_gif(){
        $image = dirname(__FILE__) . '/processing.gif';
        $base64_image = "R0lGODlhFAAUALMIAPh2AP+TMsZiALlcAKNOAOp4ANVqAP+PFv///wAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQFCgAIACwAAAAAFAAUAAAEUxDJSau9iBDMtebTMEjehgTBJYqkiaLWOlZvGs8WDO6UIPCHw8TnAwWDEuKPcxQml0Ynj2cwYACAS7VqwWItWyuiUJB4s2AxmWxGg9bl6YQtl0cAACH5BAUKAAgALAEAAQASABIAAAROEMkpx6A4W5upENUmEQT2feFIltMJYivbvhnZ3Z1h4FMQIDodz+cL7nDEn5CH8DGZhcLtcMBEoxkqlXKVIgAAibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkphaA4W5upMdUmDQP2feFIltMJYivbvhnZ3V1R4BNBIDodz+cL7nDEn5CH8DGZAMAtEMBEoxkqlXKVIg4HibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpjaE4W5tpKdUmCQL2feFIltMJYivbvhnZ3R0A4NMwIDodz+cL7nDEn5CH8DGZh8ONQMBEoxkqlXKVIgIBibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpS6E4W5spANUmGQb2feFIltMJYivbvhnZ3d1x4JMgIDodz+cL7nDEn5CH8DGZgcBtMMBEoxkqlXKVIggEibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpAaA4W5vpOdUmFQX2feFIltMJYivbvhnZ3V0Q4JNhIDodz+cL7nDEn5CH8DGZBMJNIMBEoxkqlXKVIgYDibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpz6E4W5tpCNUmAQD2feFIltMJYivbvhnZ3R1B4FNRIDodz+cL7nDEn5CH8DGZg8HNYMBEoxkqlXKVIgQCibbK9YLBYvLtHH5K0J0IACH5BAkKAAgALAEAAQASABIAAAROEMkpQ6A4W5spIdUmHQf2feFIltMJYivbvhnZ3d0w4BMAIDodz+cL7nDEn5CH8DGZAsGtUMBEoxkqlXKVIgwGibbK9YLBYvLtHH5K0J0IADs=";
        $binary = is_file($image) ? join("",file($image)) : base64_decode($base64_image); 
        header("Cache-Control: post-check=0, pre-check=0, max-age=0, no-store, no-cache, must-revalidate");
        header("Pragma: no-cache");
        header("Content-type: image/gif");
        echo $binary;
    }

}
# end of class phpfmgImage
# ------------------------------------------------------
# end of module : captcha


# module user
# ------------------------------------------------------
function phpfmg_user_isLogin(){
    return ( isset($_SESSION['authenticated']) && true === $_SESSION['authenticated'] );
}


function phpfmg_user_logout(){
    session_destroy();
    header("Location: admin.php");
}

function phpfmg_user_login()
{
    if( phpfmg_user_isLogin() ){
        return true ;
    };
    
    $sErr = "" ;
    if( 'Y' == $_POST['formmail_submit'] ){
        if(
            defined( 'PHPFMG_USER' ) && strtolower(PHPFMG_USER) == strtolower($_POST['Username']) &&
            defined( 'PHPFMG_PW' )   && strtolower(PHPFMG_PW) == strtolower($_POST['Password']) 
        ){
             $_SESSION['authenticated'] = true ;
             return true ;
             
        }else{
            $sErr = 'Login failed. Please try again.';
        }
    };
    
    // show login form 
    phpfmg_admin_header();
?>
<form name="frmFormMail" action="" method='post' enctype='multipart/form-data'>
<input type='hidden' name='formmail_submit' value='Y'>
<br><br><br>

<center>
<div style="width:380px;height:260px;">
<fieldset style="padding:18px;" >
<table cellspacing='3' cellpadding='3' border='0' >
	<tr>
		<td class="form_field" valign='top' align='right'>Email :</td>
		<td class="form_text">
            <input type="text" name="Username"  value="<?php echo $_POST['Username']; ?>" class='text_box' >
		</td>
	</tr>

	<tr>
		<td class="form_field" valign='top' align='right'>Password :</td>
		<td class="form_text">
            <input type="password" name="Password"  value="" class='text_box'>
		</td>
	</tr>

	<tr><td colspan=3 align='center'>
        <input type='submit' value='Login'><br><br>
        <?php if( $sErr ) echo "<span style='color:red;font-weight:bold;'>{$sErr}</span><br><br>\n"; ?>
        <a href="admin.php?mod=mail&func=request_password">I forgot my password</a>   
    </td></tr>
</table>
</fieldset>
</div>
<script type="text/javascript">
    document.frmFormMail.Username.focus();
</script>
</form>
<?php
    phpfmg_admin_footer();
}


function phpfmg_mail_request_password(){
    $sErr = '';
    if( $_POST['formmail_submit'] == 'Y' ){
        if( strtoupper(trim($_POST['Username'])) == strtoupper(trim(PHPFMG_USER)) ){
            phpfmg_mail_password();
            exit;
        }else{
            $sErr = "Failed to verify your email.";
        };
    };
    
    $n1 = strpos(PHPFMG_USER,'@');
    $n2 = strrpos(PHPFMG_USER,'.');
    $email = substr(PHPFMG_USER,0,1) . str_repeat('*',$n1-1) . 
            '@' . substr(PHPFMG_USER,$n1+1,1) . str_repeat('*',$n2-$n1-2) . 
            '.' . substr(PHPFMG_USER,$n2+1,1) . str_repeat('*',strlen(PHPFMG_USER)-$n2-2) ;


    phpfmg_admin_header("Request Password of Email Form Admin Panel");
?>
<form name="frmRequestPassword" action="admin.php?mod=mail&func=request_password" method='post' enctype='multipart/form-data'>
<input type='hidden' name='formmail_submit' value='Y'>
<br><br><br>

<center>
<div style="width:580px;height:260px;text-align:left;">
<fieldset style="padding:18px;" >
<legend>Request Password</legend>
Enter Email Address <b><?php echo strtoupper($email) ;?></b>:<br />
<input type="text" name="Username"  value="<?php echo $_POST['Username']; ?>" style="width:380px;">
<input type='submit' value='Verify'><br>
The password will be sent to this email address. 
<?php if( $sErr ) echo "<br /><br /><span style='color:red;font-weight:bold;'>{$sErr}</span><br><br>\n"; ?>
</fieldset>
</div>
<script type="text/javascript">
    document.frmRequestPassword.Username.focus();
</script>
</form>
<?php
    phpfmg_admin_footer();    
}


function phpfmg_mail_password(){
    phpfmg_admin_header();
    if( defined( 'PHPFMG_USER' ) && defined( 'PHPFMG_PW' ) ){
        $body = "Here is the password for your form admin panel:\n\nUsername: " . PHPFMG_USER . "\nPassword: " . PHPFMG_PW . "\n\n" ;
        if( 'html' == PHPFMG_MAIL_TYPE )
            $body = nl2br($body);
        mailAttachments( PHPFMG_USER, "Password for Your Form Admin Panel", $body, PHPFMG_USER, 'You', "You <" . PHPFMG_USER . ">" );
        echo "<center>Your password has been sent.<br><br><a href='admin.php'>Click here to login again</a></center>";
    };   
    phpfmg_admin_footer();
}


function phpfmg_writable_check(){
 
    if( is_writable( dirname(PHPFMG_SAVE_FILE) ) && is_writable( dirname(PHPFMG_EMAILS_LOGFILE) )  ){
        return ;
    };
?>
<style type="text/css">
    .fmg_warning{
        background-color: #F4F6E5;
        border: 1px dashed #ff0000;
        padding: 16px;
        color : black;
        margin: 10px;
        line-height: 180%;
        width:80%;
    }
    
    .fmg_warning_title{
        font-weight: bold;
    }

</style>
<br><br>
<div class="fmg_warning">
    <div class="fmg_warning_title">Your form data or email traffic log is NOT saving.</div>
    The form data (<?php echo PHPFMG_SAVE_FILE ?>) and email traffic log (<?php echo PHPFMG_EMAILS_LOGFILE?>) will be created automatically when the form is submitted. 
    However, the script doesn't have writable permission to create those files. In order to save your valuable information, please set the directory to writable.
     If you don't know how to do it, please ask for help from your web Administrator or Technical Support of your hosting company.   
</div>
<br><br>
<?php
}


function phpfmg_log_view(){
    $n = isset($_REQUEST['file'])  ? $_REQUEST['file']  : '';
    $files = array(
        1 => PHPFMG_EMAILS_LOGFILE,
        2 => PHPFMG_SAVE_FILE,
    );
    
    phpfmg_admin_header();
   
    $file = $files[$n];
    if( is_file($file) ){
        if( 1== $n ){
            echo "<pre>\n";
            echo join("",file($file) );
            echo "</pre>\n";
        }else{
            $man = new phpfmgDataManager();
            $man->displayRecords();
        };
     

    }else{
        echo "<b>No form data found.</b>";
    };
    phpfmg_admin_footer();
}


function phpfmg_log_download(){
    $n = isset($_REQUEST['file'])  ? $_REQUEST['file']  : '';
    $files = array(
        1 => PHPFMG_EMAILS_LOGFILE,
        2 => PHPFMG_SAVE_FILE,
    );

    $file = $files[$n];
    if( is_file($file) ){
        phpfmg_util_download( $file, PHPFMG_SAVE_FILE == $file ? 'form-data.csv' : 'email-traffics.txt', true, 1 ); // skip the first line
    }else{
        phpfmg_admin_header();
        echo "<b>No email traffic log found.</b>";
        phpfmg_admin_footer();
    };

}


function phpfmg_log_delete(){
    $n = isset($_REQUEST['file'])  ? $_REQUEST['file']  : '';
    $files = array(
        1 => PHPFMG_EMAILS_LOGFILE,
        2 => PHPFMG_SAVE_FILE,
    );
    phpfmg_admin_header();

    $file = $files[$n];
    if( is_file($file) ){
        echo unlink($file) ? "It has been deleted!" : "Failed to delete!" ;
    };
    phpfmg_admin_footer();
}


function phpfmg_util_download($file, $filename='', $toCSV = false, $skipN = 0 ){
    if (!is_file($file)) return false ;

    set_time_limit(0);


    $buffer = "";
    $i = 0 ;
    $fp = @fopen($file, 'rb');
    while( !feof($fp)) { 
        $i ++ ;
        $line = fgets($fp);
        if($i > $skipN){ // skip lines
            if( $toCSV ){ 
              $line = str_replace( chr(0x09), ',', $line );
              $buffer .= phpfmg_data2record( $line, false );
            }else{
                $buffer .= $line;
            };
        }; 
    }; 
    fclose ($fp);
  

    
    /*
        If the Content-Length is NOT THE SAME SIZE as the real conent output, Windows+IIS might be hung!!
    */
    $len = strlen($buffer);
    $filename = basename( '' == $filename ? $file : $filename );
    $file_extension = strtolower(substr(strrchr($filename,"."),1));

    switch( $file_extension ) {
        case "pdf": $ctype="application/pdf"; break;
        case "exe": $ctype="application/octet-stream"; break;
        case "zip": $ctype="application/zip"; break;
        case "doc": $ctype="application/msword"; break;
        case "xls": $ctype="application/vnd.ms-excel"; break;
        case "ppt": $ctype="application/vnd.ms-powerpoint"; break;
        case "gif": $ctype="image/gif"; break;
        case "png": $ctype="image/png"; break;
        case "jpeg":
        case "jpg": $ctype="image/jpg"; break;
        case "mp3": $ctype="audio/mpeg"; break;
        case "wav": $ctype="audio/x-wav"; break;
        case "mpeg":
        case "mpg":
        case "mpe": $ctype="video/mpeg"; break;
        case "mov": $ctype="video/quicktime"; break;
        case "avi": $ctype="video/x-msvideo"; break;
        //The following are for extensions that shouldn't be downloaded (sensitive stuff, like php files)
        case "php":
        case "htm":
        case "html": 
                $ctype="text/plain"; break;
        default: 
            $ctype="application/x-download";
    }
                                            

    //Begin writing headers
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control: public"); 
    header("Content-Description: File Transfer");
    //Use the switch-generated Content-Type
    header("Content-Type: $ctype");
    //Force the download
    header("Content-Disposition: attachment; filename=".$filename.";" );
    header("Content-Transfer-Encoding: binary");
    header("Content-Length: ".$len);
    
    while (@ob_end_clean()); // no output buffering !
    flush();
    echo $buffer ;
    
    return true;
 
    
}
?>